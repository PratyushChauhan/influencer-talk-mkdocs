# Purchasing Credits

## Credits 

* `Credits` are our app's currency.
* Everything in the app is paid through `credits`.

## Obtaining Credits

* Click on the `Credits` or coin like icon at the top of the home screen.

<img src="./credit_icon.png" width=150 >

* Tapping on this icon will take the user to the `credits shop`.

<img src="./coin_shop.png" width=150 >

* Clicking on any of the `credit` option will direct users to the payment page.
* Here, users can pay using the payment method of their choice.

<img src="./paymets.jpg" width=150 >

## Transaction History

* Tapping on this icon will take the user to the transaction history made by the user.

<img src="./transaction history.jpg" width=150 >


