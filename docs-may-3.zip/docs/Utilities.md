# Utilities

## Settings Menu

<img src="./home page.jpg" width=150 >
<img src="side_menu.jpg" width=150 >

* Clicking on the side menu button on the home page will navigate the user to the `Setings Menu`.


## Account Settings 

<img src="./account settings.jpg" width=150 >


* Contains user options for the account like changing email address, phone number and updating password
* The contact us option contains the helps user contact support
* Using the Register as an influencer button, the user can register themselves as an influencer on the app
* The user can also delete their account using the Delete Your Account option


## Edit Details


<img src="./edit details.jpg" width=150 >


* User can change their Name, Gender and Age


## Settings

<img src="./settings.jpg" width=150 >

* User can change App notification and Update preferences


## Privacy Policy


<img src="./privacy policy.jpg" width=150 >


* User can read on the app usage privacy policy and terms and conditions for using the app


## About Us


<img src="./about us.jpg" width=150 >


* Contains information about the application


## Log Out

<img src="./log out.jpg" width=150 >

* Users can log out of the application using this button





