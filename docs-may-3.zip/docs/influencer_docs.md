# Influencers Docs

## Profile
<img src="influencer_docs_profile_1.jpg" width=150 >
<img src="influencer_docs_profile_2.jpg" width=150 >
<img src="influencer_docs_profile_3.jpg" width=150 >

* Navigate to the home page and tap `view profile`.
* An influencer can change their profile details, update their social handles, and their connection charges
* They can also change their profile photo and edit or add their featured video

## Featured Videos
<img src="edit_video_1.jpg" width=150 >

* Influencers can edit featured videos from their profile page by clicking on the edit icon on the top right

<img src="edit_video.jpg" width=150 >

* They can add by clicking on the plus icon at the botton right and remove the featured videos on their profile


## Influencer Collabs

<img src="../image-3.png" width=150 >
<img src="../image-5.png" width=150 >

<img src="../image-4.png" width=150 >
<img src="./collab request.jpg" width=150 >

* Click on `Chat` to initiate a conversation with the influencer.
* Clicking on `Collabs` can intiate a collab request with another influencer

## Requests page
<img src="../image-6.png" width=150 >
<img src="../image-7.png" width=150 >
<img src="../image-8.png" width=150 >

* Influencers can view and respond to all requests at one page.

## Earnings
<img src="inf_cred1.jpg" width=150 >
<img src="inf_cred2.jpg" width=150 >


* Influencers can view their earnings and related stats.
* They can adjust the days as update bank details as well.